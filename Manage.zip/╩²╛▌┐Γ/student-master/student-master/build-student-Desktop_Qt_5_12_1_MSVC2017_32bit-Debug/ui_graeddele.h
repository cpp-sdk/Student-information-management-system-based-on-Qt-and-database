/********************************************************************************
** Form generated from reading UI file 'graeddele.ui'
**
** Created by: Qt User Interface Compiler version 5.12.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GRAEDDELE_H
#define UI_GRAEDDELE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_graeddele
{
public:
    QWidget *centralwidget;
    QLineEdit *lineEdit_sno;
    QPushButton *pushButton_dele;
    QPushButton *pushButton_exit;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit_cno;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *graeddele)
    {
        if (graeddele->objectName().isEmpty())
            graeddele->setObjectName(QString::fromUtf8("graeddele"));
        graeddele->resize(453, 260);
        centralwidget = new QWidget(graeddele);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        lineEdit_sno = new QLineEdit(centralwidget);
        lineEdit_sno->setObjectName(QString::fromUtf8("lineEdit_sno"));
        lineEdit_sno->setGeometry(QRect(190, 60, 113, 20));
        pushButton_dele = new QPushButton(centralwidget);
        pushButton_dele->setObjectName(QString::fromUtf8("pushButton_dele"));
        pushButton_dele->setGeometry(QRect(110, 150, 75, 23));
        pushButton_exit = new QPushButton(centralwidget);
        pushButton_exit->setObjectName(QString::fromUtf8("pushButton_exit"));
        pushButton_exit->setGeometry(QRect(230, 150, 75, 23));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(130, 60, 51, 31));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(120, 100, 51, 31));
        lineEdit_cno = new QLineEdit(centralwidget);
        lineEdit_cno->setObjectName(QString::fromUtf8("lineEdit_cno"));
        lineEdit_cno->setGeometry(QRect(190, 100, 113, 20));
        graeddele->setCentralWidget(centralwidget);
        menubar = new QMenuBar(graeddele);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 453, 26));
        graeddele->setMenuBar(menubar);
        statusbar = new QStatusBar(graeddele);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        graeddele->setStatusBar(statusbar);

        retranslateUi(graeddele);

        QMetaObject::connectSlotsByName(graeddele);
    } // setupUi

    void retranslateUi(QMainWindow *graeddele)
    {
        graeddele->setWindowTitle(QApplication::translate("graeddele", "MainWindow", nullptr));
        pushButton_dele->setText(QApplication::translate("graeddele", "\345\210\240\351\231\244", nullptr));
        pushButton_exit->setText(QApplication::translate("graeddele", "\351\200\200\345\207\272", nullptr));
        label->setText(QApplication::translate("graeddele", "\345\255\246\345\217\267", nullptr));
        label_2->setText(QApplication::translate("graeddele", "\350\257\276\347\250\213\345\217\267", nullptr));
    } // retranslateUi

};

namespace Ui {
    class graeddele: public Ui_graeddele {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GRAEDDELE_H
