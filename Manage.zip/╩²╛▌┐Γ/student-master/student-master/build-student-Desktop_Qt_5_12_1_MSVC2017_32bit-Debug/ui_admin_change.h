/********************************************************************************
** Form generated from reading UI file 'admin_change.ui'
**
** Created by: Qt User Interface Compiler version 5.12.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMIN_CHANGE_H
#define UI_ADMIN_CHANGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_admin_change
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *lineEdit_number;
    QLabel *label_5;
    QLineEdit *lineEdit_sex;
    QLineEdit *lineEdit_class;
    QLineEdit *lineEdit_age;
    QLineEdit *lineEdit_name;
    QPushButton *pushButton_enter;
    QPushButton *pushButton_exit;
    QLabel *label_6;
    QLineEdit *lineEdit_passowrd;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *admin_change)
    {
        if (admin_change->objectName().isEmpty())
            admin_change->setObjectName(QString::fromUtf8("admin_change"));
        admin_change->resize(336, 351);
        centralwidget = new QWidget(admin_change);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(80, 40, 41, 21));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(80, 160, 51, 21));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(80, 100, 61, 21));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(80, 130, 41, 21));
        lineEdit_number = new QLineEdit(centralwidget);
        lineEdit_number->setObjectName(QString::fromUtf8("lineEdit_number"));
        lineEdit_number->setGeometry(QRect(160, 40, 113, 20));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(80, 70, 51, 21));
        lineEdit_sex = new QLineEdit(centralwidget);
        lineEdit_sex->setObjectName(QString::fromUtf8("lineEdit_sex"));
        lineEdit_sex->setGeometry(QRect(160, 100, 113, 20));
        lineEdit_class = new QLineEdit(centralwidget);
        lineEdit_class->setObjectName(QString::fromUtf8("lineEdit_class"));
        lineEdit_class->setGeometry(QRect(160, 160, 113, 20));
        lineEdit_age = new QLineEdit(centralwidget);
        lineEdit_age->setObjectName(QString::fromUtf8("lineEdit_age"));
        lineEdit_age->setGeometry(QRect(160, 130, 113, 20));
        lineEdit_name = new QLineEdit(centralwidget);
        lineEdit_name->setObjectName(QString::fromUtf8("lineEdit_name"));
        lineEdit_name->setGeometry(QRect(160, 70, 113, 20));
        pushButton_enter = new QPushButton(centralwidget);
        pushButton_enter->setObjectName(QString::fromUtf8("pushButton_enter"));
        pushButton_enter->setGeometry(QRect(60, 240, 75, 23));
        pushButton_exit = new QPushButton(centralwidget);
        pushButton_exit->setObjectName(QString::fromUtf8("pushButton_exit"));
        pushButton_exit->setGeometry(QRect(190, 240, 75, 23));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(80, 190, 41, 21));
        lineEdit_passowrd = new QLineEdit(centralwidget);
        lineEdit_passowrd->setObjectName(QString::fromUtf8("lineEdit_passowrd"));
        lineEdit_passowrd->setGeometry(QRect(160, 190, 113, 20));
        admin_change->setCentralWidget(centralwidget);
        menubar = new QMenuBar(admin_change);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 336, 26));
        admin_change->setMenuBar(menubar);
        statusbar = new QStatusBar(admin_change);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        admin_change->setStatusBar(statusbar);

        retranslateUi(admin_change);

        QMetaObject::connectSlotsByName(admin_change);
    } // setupUi

    void retranslateUi(QMainWindow *admin_change)
    {
        admin_change->setWindowTitle(QApplication::translate("admin_change", "MainWindow", nullptr));
        label->setText(QApplication::translate("admin_change", "\345\255\246\345\217\267", nullptr));
        label_2->setText(QApplication::translate("admin_change", "\344\270\223\344\270\232", nullptr));
        label_3->setText(QApplication::translate("admin_change", "\346\200\247\345\210\253", nullptr));
        label_4->setText(QApplication::translate("admin_change", "\345\271\264\351\276\204", nullptr));
        label_5->setText(QApplication::translate("admin_change", "\345\247\223\345\220\215", nullptr));
        pushButton_enter->setText(QApplication::translate("admin_change", "\347\241\256\345\256\232", nullptr));
        pushButton_exit->setText(QApplication::translate("admin_change", "\351\200\200\345\207\272", nullptr));
        label_6->setText(QApplication::translate("admin_change", "\345\257\206\347\240\201", nullptr));
    } // retranslateUi

};

namespace Ui {
    class admin_change: public Ui_admin_change {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMIN_CHANGE_H
