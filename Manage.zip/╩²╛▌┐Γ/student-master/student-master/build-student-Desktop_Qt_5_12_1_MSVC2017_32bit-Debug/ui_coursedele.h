/********************************************************************************
** Form generated from reading UI file 'coursedele.ui'
**
** Created by: Qt User Interface Compiler version 5.12.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_COURSEDELE_H
#define UI_COURSEDELE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_coursedele
{
public:
    QWidget *centralwidget;
    QLineEdit *lineEdit_name;
    QPushButton *pushButton_dele;
    QPushButton *pushButton_exit;
    QLabel *label;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *coursedele)
    {
        if (coursedele->objectName().isEmpty())
            coursedele->setObjectName(QString::fromUtf8("coursedele"));
        coursedele->resize(410, 284);
        centralwidget = new QWidget(coursedele);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        lineEdit_name = new QLineEdit(centralwidget);
        lineEdit_name->setObjectName(QString::fromUtf8("lineEdit_name"));
        lineEdit_name->setGeometry(QRect(210, 80, 113, 20));
        pushButton_dele = new QPushButton(centralwidget);
        pushButton_dele->setObjectName(QString::fromUtf8("pushButton_dele"));
        pushButton_dele->setGeometry(QRect(90, 170, 75, 23));
        pushButton_exit = new QPushButton(centralwidget);
        pushButton_exit->setObjectName(QString::fromUtf8("pushButton_exit"));
        pushButton_exit->setGeometry(QRect(270, 170, 75, 23));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(110, 80, 51, 31));
        coursedele->setCentralWidget(centralwidget);
        menubar = new QMenuBar(coursedele);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 410, 26));
        coursedele->setMenuBar(menubar);
        statusbar = new QStatusBar(coursedele);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        coursedele->setStatusBar(statusbar);

        retranslateUi(coursedele);

        QMetaObject::connectSlotsByName(coursedele);
    } // setupUi

    void retranslateUi(QMainWindow *coursedele)
    {
        coursedele->setWindowTitle(QApplication::translate("coursedele", "MainWindow", nullptr));
        pushButton_dele->setText(QApplication::translate("coursedele", "\345\210\240\351\231\244", nullptr));
        pushButton_exit->setText(QApplication::translate("coursedele", "\351\200\200\345\207\272", nullptr));
        label->setText(QApplication::translate("coursedele", "\350\257\276\347\250\213\345\217\267", nullptr));
    } // retranslateUi

};

namespace Ui {
    class coursedele: public Ui_coursedele {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_COURSEDELE_H
