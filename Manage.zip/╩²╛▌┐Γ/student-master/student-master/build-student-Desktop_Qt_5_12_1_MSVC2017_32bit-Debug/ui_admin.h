/********************************************************************************
** Form generated from reading UI file 'admin.ui'
**
** Created by: Qt User Interface Compiler version 5.12.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMIN_H
#define UI_ADMIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_admin
{
public:
    QWidget *centralwidget;
    QTableView *tableView;
    QPushButton *pushButton_exit;
    QPushButton *pushButton_show;
    QPushButton *pushButton_change;
    QPushButton *pushButton_del;
    QLineEdit *lineEdit_findname;
    QComboBox *comboBox;
    QPushButton *pushButton_order;
    QCheckBox *checkBox_desc;
    QPushButton *pushButton_show_2;
    QPushButton *pushButton_show_3;
    QComboBox *comboBox_2;
    QTableView *tableView_2;
    QLabel *label;
    QPushButton *pushButton_show_4;
    QLabel *label_4;
    QMenuBar *menubar;
    QStatusBar *statusbar;
    QToolBar *toolBar;
    QToolBar *toolBar_2;

    void setupUi(QMainWindow *admin)
    {
        if (admin->objectName().isEmpty())
            admin->setObjectName(QString::fromUtf8("admin"));
        admin->resize(732, 555);
        centralwidget = new QWidget(admin);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        tableView = new QTableView(centralwidget);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(140, 110, 581, 301));
        pushButton_exit = new QPushButton(centralwidget);
        pushButton_exit->setObjectName(QString::fromUtf8("pushButton_exit"));
        pushButton_exit->setGeometry(QRect(310, 440, 111, 41));
        pushButton_exit->setStyleSheet(QString::fromUtf8("QPushButton:hover\n"
"{\n"
"	background-color: qlineargradient(spread:pad, x1:0.909, y1:0.864, x2:0.926, y2:0, stop:0.448864 rgba(255, 239, 88, 250), stop:1 rgba(255, 255, 255, 255));\n"
"	\n"
"}\n"
""));
        pushButton_show = new QPushButton(centralwidget);
        pushButton_show->setObjectName(QString::fromUtf8("pushButton_show"));
        pushButton_show->setGeometry(QRect(20, 170, 91, 31));
        pushButton_show->setStyleSheet(QString::fromUtf8("QPushButton:hover\n"
"{\n"
"	background-color: qlineargradient(spread:pad, x1:0.909, y1:0.864, x2:0.926, y2:0, stop:0.448864 rgba(255, 239, 88, 250), stop:1 rgba(255, 255, 255, 255));\n"
"	\n"
"}\n"
""));
        pushButton_change = new QPushButton(centralwidget);
        pushButton_change->setObjectName(QString::fromUtf8("pushButton_change"));
        pushButton_change->setGeometry(QRect(20, 330, 91, 31));
        pushButton_del = new QPushButton(centralwidget);
        pushButton_del->setObjectName(QString::fromUtf8("pushButton_del"));
        pushButton_del->setGeometry(QRect(20, 390, 91, 31));
        lineEdit_findname = new QLineEdit(centralwidget);
        lineEdit_findname->setObjectName(QString::fromUtf8("lineEdit_findname"));
        lineEdit_findname->setGeometry(QRect(310, 60, 121, 21));
        comboBox = new QComboBox(centralwidget);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(460, 60, 81, 22));
        pushButton_order = new QPushButton(centralwidget);
        pushButton_order->setObjectName(QString::fromUtf8("pushButton_order"));
        pushButton_order->setGeometry(QRect(630, 60, 75, 23));
        pushButton_order->setStyleSheet(QString::fromUtf8("QPushButton:hover\n"
"{\n"
"	background-color: qlineargradient(spread:pad, x1:0.909, y1:0.864, x2:0.926, y2:0, stop:0.448864 rgba(255, 239, 88, 250), stop:1 rgba(255, 255, 255, 255));\n"
"	\n"
"}\n"
""));
        checkBox_desc = new QCheckBox(centralwidget);
        checkBox_desc->setObjectName(QString::fromUtf8("checkBox_desc"));
        checkBox_desc->setGeometry(QRect(560, 60, 71, 16));
        pushButton_show_2 = new QPushButton(centralwidget);
        pushButton_show_2->setObjectName(QString::fromUtf8("pushButton_show_2"));
        pushButton_show_2->setGeometry(QRect(20, 220, 91, 31));
        pushButton_show_2->setStyleSheet(QString::fromUtf8("QPushButton:hover\n"
"{\n"
"	background-color: qlineargradient(spread:pad, x1:0.909, y1:0.864, x2:0.926, y2:0, stop:0.448864 rgba(255, 239, 88, 250), stop:1 rgba(255, 255, 255, 255));\n"
"	\n"
"}\n"
""));
        pushButton_show_3 = new QPushButton(centralwidget);
        pushButton_show_3->setObjectName(QString::fromUtf8("pushButton_show_3"));
        pushButton_show_3->setGeometry(QRect(20, 270, 91, 31));
        pushButton_show_3->setStyleSheet(QString::fromUtf8("QPushButton:hover\n"
"{\n"
"	background-color: qlineargradient(spread:pad, x1:0.909, y1:0.864, x2:0.926, y2:0, stop:0.448864 rgba(255, 239, 88, 250), stop:1 rgba(255, 255, 255, 255));\n"
"	\n"
"}\n"
""));
        comboBox_2 = new QComboBox(centralwidget);
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));
        comboBox_2->setGeometry(QRect(190, 60, 101, 21));
        tableView_2 = new QTableView(centralwidget);
        tableView_2->setObjectName(QString::fromUtf8("tableView_2"));
        tableView_2->setGeometry(QRect(60, 50, 101, 41));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 60, 41, 21));
        pushButton_show_4 = new QPushButton(centralwidget);
        pushButton_show_4->setObjectName(QString::fromUtf8("pushButton_show_4"));
        pushButton_show_4->setGeometry(QRect(20, 120, 91, 31));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(-40, -10, 1221, 721));
        label_4->setStyleSheet(QString::fromUtf8("background-image: url(C:/Users/wxy/Desktop/123.jpg);"));
        admin->setCentralWidget(centralwidget);
        label_4->raise();
        tableView->raise();
        pushButton_exit->raise();
        pushButton_show->raise();
        pushButton_change->raise();
        pushButton_del->raise();
        lineEdit_findname->raise();
        comboBox->raise();
        pushButton_order->raise();
        checkBox_desc->raise();
        pushButton_show_2->raise();
        pushButton_show_3->raise();
        comboBox_2->raise();
        tableView_2->raise();
        label->raise();
        pushButton_show_4->raise();
        menubar = new QMenuBar(admin);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 732, 26));
        admin->setMenuBar(menubar);
        statusbar = new QStatusBar(admin);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        admin->setStatusBar(statusbar);
        toolBar = new QToolBar(admin);
        toolBar->setObjectName(QString::fromUtf8("toolBar"));
        admin->addToolBar(Qt::TopToolBarArea, toolBar);
        toolBar_2 = new QToolBar(admin);
        toolBar_2->setObjectName(QString::fromUtf8("toolBar_2"));
        admin->addToolBar(Qt::TopToolBarArea, toolBar_2);

        retranslateUi(admin);

        QMetaObject::connectSlotsByName(admin);
    } // setupUi

    void retranslateUi(QMainWindow *admin)
    {
        admin->setWindowTitle(QApplication::translate("admin", "\347\256\241\347\220\206\345\221\230\347\225\214\351\235\242", nullptr));
        pushButton_exit->setText(QApplication::translate("admin", "\351\200\200\345\207\272", nullptr));
        pushButton_show->setText(QApplication::translate("admin", "\345\255\246\347\224\237\344\277\241\346\201\257", nullptr));
        pushButton_change->setText(QApplication::translate("admin", "\346\267\273\345\212\240\344\277\241\346\201\257", nullptr));
        pushButton_del->setText(QApplication::translate("admin", "\345\210\240\351\231\244\344\277\241\346\201\257", nullptr));
        comboBox->setItemText(0, QApplication::translate("admin", "\345\255\246\345\217\267", nullptr));
        comboBox->setItemText(1, QApplication::translate("admin", "\345\271\264\351\276\204", nullptr));
        comboBox->setItemText(2, QApplication::translate("admin", "\345\255\246\345\210\206", nullptr));
        comboBox->setItemText(3, QApplication::translate("admin", "\346\210\220\347\273\251", nullptr));
        comboBox->setItemText(4, QApplication::translate("admin", "\350\257\276\347\250\213\345\217\267", nullptr));

        pushButton_order->setText(QApplication::translate("admin", "\346\216\222\345\272\217", nullptr));
        checkBox_desc->setText(QApplication::translate("admin", "\351\231\215\345\272\217", nullptr));
        pushButton_show_2->setText(QApplication::translate("admin", "\350\257\276\347\250\213\344\277\241\346\201\257", nullptr));
        pushButton_show_3->setText(QApplication::translate("admin", "\345\255\246\347\224\237\346\210\220\347\273\251", nullptr));
        comboBox_2->setItemText(0, QApplication::translate("admin", "\345\247\223\345\220\215\346\220\234\347\264\242", nullptr));
        comboBox_2->setItemText(1, QApplication::translate("admin", "\345\255\246\345\217\267\346\220\234\347\264\242", nullptr));
        comboBox_2->setItemText(2, QApplication::translate("admin", "\350\257\276\347\250\213\346\220\234\347\264\242", nullptr));

        label->setText(QApplication::translate("admin", "\350\200\201\345\270\210", nullptr));
        pushButton_show_4->setText(QApplication::translate("admin", "\344\277\256\346\224\271\345\257\206\347\240\201", nullptr));
        label_4->setText(QApplication::translate("admin", "<html><head/><body><p><br/></p></body></html>", nullptr));
        toolBar->setWindowTitle(QApplication::translate("admin", "toolBar", nullptr));
        toolBar_2->setWindowTitle(QApplication::translate("admin", "toolBar_2", nullptr));
    } // retranslateUi

};

namespace Ui {
    class admin: public Ui_admin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMIN_H
