/********************************************************************************
** Form generated from reading UI file 'grade.ui'
**
** Created by: Qt User Interface Compiler version 5.12.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GRADE_H
#define UI_GRADE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_grade
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton_enter;
    QLabel *label_5;
    QLineEdit *lineEdit_number;
    QLabel *label_2;
    QPushButton *pushButton_exit;
    QLabel *label;
    QLineEdit *lineEdit_name;
    QLineEdit *lineEdit_grade;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *grade)
    {
        if (grade->objectName().isEmpty())
            grade->setObjectName(QString::fromUtf8("grade"));
        grade->resize(380, 288);
        centralwidget = new QWidget(grade);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        pushButton_enter = new QPushButton(centralwidget);
        pushButton_enter->setObjectName(QString::fromUtf8("pushButton_enter"));
        pushButton_enter->setGeometry(QRect(80, 190, 75, 23));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(80, 90, 51, 31));
        lineEdit_number = new QLineEdit(centralwidget);
        lineEdit_number->setObjectName(QString::fromUtf8("lineEdit_number"));
        lineEdit_number->setGeometry(QRect(150, 50, 113, 20));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(80, 140, 51, 21));
        pushButton_exit = new QPushButton(centralwidget);
        pushButton_exit->setObjectName(QString::fromUtf8("pushButton_exit"));
        pushButton_exit->setGeometry(QRect(190, 190, 75, 23));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(80, 40, 61, 31));
        lineEdit_name = new QLineEdit(centralwidget);
        lineEdit_name->setObjectName(QString::fromUtf8("lineEdit_name"));
        lineEdit_name->setGeometry(QRect(150, 100, 113, 20));
        lineEdit_grade = new QLineEdit(centralwidget);
        lineEdit_grade->setObjectName(QString::fromUtf8("lineEdit_grade"));
        lineEdit_grade->setGeometry(QRect(150, 140, 113, 20));
        grade->setCentralWidget(centralwidget);
        menubar = new QMenuBar(grade);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 380, 26));
        grade->setMenuBar(menubar);
        statusbar = new QStatusBar(grade);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        grade->setStatusBar(statusbar);

        retranslateUi(grade);

        QMetaObject::connectSlotsByName(grade);
    } // setupUi

    void retranslateUi(QMainWindow *grade)
    {
        grade->setWindowTitle(QApplication::translate("grade", "MainWindow", nullptr));
        pushButton_enter->setText(QApplication::translate("grade", "\347\241\256\345\256\232", nullptr));
        label_5->setText(QApplication::translate("grade", "\350\257\276\347\250\213\345\217\267", nullptr));
        label_2->setText(QApplication::translate("grade", "\346\210\220\347\273\251", nullptr));
        pushButton_exit->setText(QApplication::translate("grade", "\351\200\200\345\207\272", nullptr));
        label->setText(QApplication::translate("grade", "\345\255\246\345\217\267", nullptr));
    } // retranslateUi

};

namespace Ui {
    class grade: public Ui_grade {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GRADE_H
