/********************************************************************************
** Form generated from reading UI file 'change.ui'
**
** Created by: Qt User Interface Compiler version 5.12.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHANGE_H
#define UI_CHANGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_change
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton_dele;
    QLineEdit *lineEdit_name;
    QPushButton *pushButton_exit;
    QLabel *label;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *change)
    {
        if (change->objectName().isEmpty())
            change->setObjectName(QString::fromUtf8("change"));
        change->resize(389, 226);
        centralwidget = new QWidget(change);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        pushButton_dele = new QPushButton(centralwidget);
        pushButton_dele->setObjectName(QString::fromUtf8("pushButton_dele"));
        pushButton_dele->setGeometry(QRect(90, 130, 75, 23));
        lineEdit_name = new QLineEdit(centralwidget);
        lineEdit_name->setObjectName(QString::fromUtf8("lineEdit_name"));
        lineEdit_name->setGeometry(QRect(130, 80, 113, 20));
        pushButton_exit = new QPushButton(centralwidget);
        pushButton_exit->setObjectName(QString::fromUtf8("pushButton_exit"));
        pushButton_exit->setGeometry(QRect(210, 130, 75, 23));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(130, 40, 111, 21));
        change->setCentralWidget(centralwidget);
        menubar = new QMenuBar(change);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 389, 26));
        change->setMenuBar(menubar);
        statusbar = new QStatusBar(change);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        change->setStatusBar(statusbar);

        retranslateUi(change);

        QMetaObject::connectSlotsByName(change);
    } // setupUi

    void retranslateUi(QMainWindow *change)
    {
        change->setWindowTitle(QApplication::translate("change", "MainWindow", nullptr));
        pushButton_dele->setText(QApplication::translate("change", "\347\241\256\345\256\232", nullptr));
        pushButton_exit->setText(QApplication::translate("change", "\351\200\200\345\207\272", nullptr));
        label->setText(QApplication::translate("change", "\346\202\250\350\246\201\344\277\256\346\224\271\347\232\204\346\225\260\346\215\256", nullptr));
    } // retranslateUi

};

namespace Ui {
    class change: public Ui_change {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHANGE_H
