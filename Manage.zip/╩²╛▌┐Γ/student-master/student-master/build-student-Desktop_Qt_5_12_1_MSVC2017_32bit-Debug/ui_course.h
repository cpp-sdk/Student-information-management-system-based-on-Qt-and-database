/********************************************************************************
** Form generated from reading UI file 'course.ui'
**
** Created by: Qt User Interface Compiler version 5.12.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_COURSE_H
#define UI_COURSE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_course
{
public:
    QWidget *centralwidget;
    QLabel *label_3;
    QLineEdit *lineEdit_name;
    QLabel *label_2;
    QLabel *label_5;
    QLineEdit *lineEdit_xianxiu;
    QPushButton *pushButton_exit;
    QLineEdit *lineEdit_number;
    QLabel *label;
    QPushButton *pushButton_enter;
    QLineEdit *lineEdit_credit;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *course)
    {
        if (course->objectName().isEmpty())
            course->setObjectName(QString::fromUtf8("course"));
        course->resize(346, 320);
        centralwidget = new QWidget(course);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(80, 160, 41, 41));
        lineEdit_name = new QLineEdit(centralwidget);
        lineEdit_name->setObjectName(QString::fromUtf8("lineEdit_name"));
        lineEdit_name->setGeometry(QRect(140, 100, 113, 20));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(70, 130, 51, 21));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(70, 90, 51, 31));
        lineEdit_xianxiu = new QLineEdit(centralwidget);
        lineEdit_xianxiu->setObjectName(QString::fromUtf8("lineEdit_xianxiu"));
        lineEdit_xianxiu->setGeometry(QRect(140, 130, 113, 20));
        pushButton_exit = new QPushButton(centralwidget);
        pushButton_exit->setObjectName(QString::fromUtf8("pushButton_exit"));
        pushButton_exit->setGeometry(QRect(210, 230, 75, 23));
        lineEdit_number = new QLineEdit(centralwidget);
        lineEdit_number->setObjectName(QString::fromUtf8("lineEdit_number"));
        lineEdit_number->setGeometry(QRect(140, 60, 113, 20));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(70, 50, 61, 31));
        pushButton_enter = new QPushButton(centralwidget);
        pushButton_enter->setObjectName(QString::fromUtf8("pushButton_enter"));
        pushButton_enter->setGeometry(QRect(80, 230, 75, 23));
        lineEdit_credit = new QLineEdit(centralwidget);
        lineEdit_credit->setObjectName(QString::fromUtf8("lineEdit_credit"));
        lineEdit_credit->setGeometry(QRect(140, 170, 113, 20));
        course->setCentralWidget(centralwidget);
        menubar = new QMenuBar(course);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 346, 26));
        course->setMenuBar(menubar);
        statusbar = new QStatusBar(course);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        course->setStatusBar(statusbar);

        retranslateUi(course);

        QMetaObject::connectSlotsByName(course);
    } // setupUi

    void retranslateUi(QMainWindow *course)
    {
        course->setWindowTitle(QApplication::translate("course", "MainWindow", nullptr));
        label_3->setText(QApplication::translate("course", "\345\255\246\345\210\206", nullptr));
        label_2->setText(QApplication::translate("course", "\345\205\210\344\277\256\350\257\276", nullptr));
        label_5->setText(QApplication::translate("course", "\350\257\276\347\250\213\345\220\215", nullptr));
        pushButton_exit->setText(QApplication::translate("course", "\351\200\200\345\207\272", nullptr));
        label->setText(QApplication::translate("course", "\350\257\276\347\250\213\345\217\267", nullptr));
        pushButton_enter->setText(QApplication::translate("course", "\347\241\256\345\256\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class course: public Ui_course {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_COURSE_H
