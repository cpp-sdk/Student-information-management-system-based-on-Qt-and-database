/********************************************************************************
** Form generated from reading UI file 'student.ui'
**
** Created by: Qt User Interface Compiler version 5.12.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STUDENT_H
#define UI_STUDENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_student
{
public:
    QWidget *centralwidget;
    QTableView *tableView;
    QPushButton *pushButton;
    QTableView *tableView_2;
    QLabel *label;
    QLabel *label_2;
    QTableView *tableView_3;
    QTableView *tableView_4;
    QLabel *label_3;
    QPushButton *pushButton_2;
    QLabel *label_4;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *student)
    {
        if (student->objectName().isEmpty())
            student->setObjectName(QString::fromUtf8("student"));
        student->resize(708, 418);
        centralwidget = new QWidget(student);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        tableView = new QTableView(centralwidget);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(10, 90, 681, 151));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(290, 320, 91, 41));
        tableView_2 = new QTableView(centralwidget);
        tableView_2->setObjectName(QString::fromUtf8("tableView_2"));
        tableView_2->setGeometry(QRect(60, 20, 261, 41));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 30, 41, 21));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 270, 51, 21));
        tableView_3 = new QTableView(centralwidget);
        tableView_3->setObjectName(QString::fromUtf8("tableView_3"));
        tableView_3->setGeometry(QRect(100, 260, 121, 41));
        tableView_4 = new QTableView(centralwidget);
        tableView_4->setObjectName(QString::fromUtf8("tableView_4"));
        tableView_4->setGeometry(QRect(460, 260, 121, 41));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(400, 270, 51, 21));
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(470, 20, 91, 41));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(-10, 0, 741, 421));
        label_4->setStyleSheet(QString::fromUtf8("background-image: url(C:/Users/wxy/Desktop/123.jpg);"));
        student->setCentralWidget(centralwidget);
        label_4->raise();
        tableView->raise();
        pushButton->raise();
        tableView_2->raise();
        label->raise();
        label_2->raise();
        tableView_3->raise();
        tableView_4->raise();
        label_3->raise();
        pushButton_2->raise();
        menubar = new QMenuBar(student);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 708, 26));
        student->setMenuBar(menubar);
        statusbar = new QStatusBar(student);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        student->setStatusBar(statusbar);

        retranslateUi(student);

        QMetaObject::connectSlotsByName(student);
    } // setupUi

    void retranslateUi(QMainWindow *student)
    {
        student->setWindowTitle(QApplication::translate("student", "MainWindow", nullptr));
        pushButton->setText(QApplication::translate("student", "\351\200\200\345\207\272", nullptr));
        label->setText(QApplication::translate("student", "\345\255\246\347\224\237", nullptr));
        label_2->setText(QApplication::translate("student", "\345\271\263\345\235\207\345\210\206", nullptr));
        label_3->setText(QApplication::translate("student", "\346\200\273\345\255\246\345\210\206", nullptr));
        pushButton_2->setText(QApplication::translate("student", "\344\277\256\346\224\271\345\257\206\347\240\201", nullptr));
        label_4->setText(QApplication::translate("student", "<html><head/><body><p><br/></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class student: public Ui_student {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STUDENT_H
