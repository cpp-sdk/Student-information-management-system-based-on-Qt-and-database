﻿#include "mainwindow.h"
#include <QApplication>
#include<QDebug>
#include<QSqlDatabase>
bool opendatabase();
int main(int argc, char *argv[])
{
    opendatabase();
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();
}
bool opendatabase()
{
    QSqlDatabase mydb=QSqlDatabase::addDatabase("QSQLITE");
    mydb.setDatabaseName("C:\\Users\\wxy\\Desktop\\新建文件夹\\数据库\\student-master\\student.db");//平时debug正常用
    //mydb.setDatabaseName("./student.db");//release用
    if(mydb.open())
    {
        qDebug()<<"open success";
        return true;
    }
    else
    {
        qDebug()<<"open failed";
        return false;
    }
}
